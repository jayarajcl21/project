package com.crm.app.admin.dto;

public enum TicketStatus {

	OPEN,
    IN_PROGRESS,
    RESOLVED,
    CLOSED,
    REOPENED
}
